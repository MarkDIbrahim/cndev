<?php
materialis_get_footer_content();
wp_footer();
?>
</body>
</html>
