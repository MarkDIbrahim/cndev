<?php

return array (
  'pro-header-1' => 
  array (
    'index' => 4,
    'id' => 'header_preset_4',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-1.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-1.png',
    'description' => 'Video in lightbox',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-10' => 
  array (
    'index' => 5,
    'id' => 'header_preset_5',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-10.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-10.png',
    'description' => 'Video and text header',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-11' => 
  array (
    'index' => 6,
    'id' => 'header_preset_6',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-11.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-11.png',
    'description' => 'PR consulting',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-12' => 
  array (
    'index' => 7,
    'id' => 'header_preset_7',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-12.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-12.png',
    'description' => 'Thai massage',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-2' => 
  array (
    'index' => 8,
    'id' => 'header_preset_8',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-2.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-2.png',
    'description' => 'Creative agency',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-4' => 
  array (
    'index' => 9,
    'id' => 'header_preset_9',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-4.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-4.png',
    'description' => 'Interior design',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-5' => 
  array (
    'index' => 10,
    'id' => 'header_preset_10',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-5.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-5.png',
    'description' => 'Personal portfolio',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-7' => 
  array (
    'index' => 11,
    'id' => 'header_preset_11',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-7.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-7.png',
    'description' => 'Mobile app',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-8' => 
  array (
    'index' => 12,
    'id' => 'header_preset_12',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-8.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-8.png',
    'description' => 'Web app',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro-header-9' => 
  array (
    'index' => 13,
    'id' => 'header_preset_13',
    'thumb' => '//onepageexpress.com/default-assets/previews/headers/pro-header-9.png',
    'preview' => '//onepageexpress.com/default-assets/previews/headers/pro-header-9.png',
    'description' => 'Multiple images',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
);
